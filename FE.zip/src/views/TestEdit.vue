<template>
  <div v-if="test" class="row">
    <div class="col-md-12">
      <h4>Hiệu chỉnh bài kiểm tra</h4>
      <TestForm :test="test" @test-submit="updateTest" @test-delete="deleteTest" />
      <p>{{ message }}</p>
    </div>
  </div>
  <div v-else>
    <br />
    <p>Bài kiểm tra không tìm thấy.</p>
  </div>
</template>
<script>
import TestService from "../services/test.service";
import TestForm from "../components/TestForm";
export default {
  name: "TestEdit",
  components: {
    TestForm,
  },
  data() {
    return {
      test: null,
      message: "",
    };
  },
  methods: {
    async getTest(id) {
      const [error, response] = await this.handle(TestService.get(id));
      if (error) {
        console.log(error);
      } else {
        this.test = response.data;
        console.log(response.data);
      }
    },
    async updateTest(data) {
      const [error, response] = await this.handle(TestService.update(this.test.id, data));
      if (error) {
        console.log(error);
      } else {
        console.log(response.data);
        this.message = "Bài kiểm tra được cập nhật thành công.";
      }
    },
    async deleteTest() {
      const [error, response] = await this.handle(TestService.delete(this.test.id));
      if (error) {
        console.log(error);
      } else {
        console.log(response.data);
        // Chuyển sang route /testbook
        this.$router.push({ name: "TestBook" });
      }
    },
  },
  mounted() {
    this.message = "";
    this.getTest(this.$route.params.id);
  },
};
</script>
<style></style>
