<template>
  <div class="row">
    <div v-show="false" class="col-md-12">
      <ckeditor :editor="editor" v-model="editorData" :config="editorConfig"></ckeditor>
      <code>{{ editorData }}</code>
    </div>
    <div class="col-md-12">
      <div class="mb-3 input-group">
        <input
          type="text"
          class="form-control"
          placeholder="Tìm theo tên bài kiểm tra"
          v-model="nameToSearch"
        />
        <div class="input-group-append">
          <button class="btn btn-success border-0" type="button" @click="searchName">
            <i class="fa fa-search" aria-hidden="true"></i>
          </button>
        </div>
      </div>
    </div>
    <div class="col-md-12">
      <div class="row">
        <div class="col-md-6 mb-4">
          <h4><i class="fas fa-window-restore"></i>&nbsp;Danh sách bài</h4>
          <div class="row">
            <div class="col-md-12">
              <button
                v-if="currentUser !== null && currentUser.isAdmin"
                class="mt-3 btn btn-sm btn-danger"
                @click="goToAddTest"
              >
                <i class="fas fa-plus-circle"></i>&nbsp;Thêm bài kiểm tra
              </button>
              <button
                v-if="showDeleteAll"
                class="mt-3 ml-2 btn btn-sm btn-danger"
                @click="removeAllTest"
              >
                Xóa tất cả
              </button>
            </div>
            <div class="col-md-12 mt-4">
              <ul class="list-group">
                <li
                  class="list-group-item"
                  :class="{ active: index == currentIndex }"
                  v-for="(test, index) in tests"
                  v-show="test.visible || (currentUser !== null && currentUser.isAdmin)"
                  :key="test.id"
                  @click="setActiveTest(test, index)"
                >
                  <div class="media">
                    <div class="media-body">
                      <h5 class="mt-0">
                        <i class="fas fa-trophy"></i>&nbsp;{{ test.name }}
                      </h5>
                    </div>
                    <!-- <img width="100" src="../assets/tests.svg" class="ml-2 rounded" /> -->
                  </div>
                </li>
              </ul>
            </div>
            <div class="col-md-12">
              <img src="../assets/graduation.svg" class="img-fluid" alt="" />
            </div>
          </div>
        </div>
        <div class="col-md-6 mb-4">
          <div class="row">
            <div class="col-md-12" v-show="!currentTest">
              <!-- <img src="../assets/working.svg" class="img-fluid" alt="" /> -->
            </div>
            <div class="col-md-12" v-if="currentTest">
              <TestDetails :test="currentTest" />
              <router-link
                v-if="currentUser !== null && currentUser.isAdmin"
                :to="'/edit-test/' + currentTest.id"
              >
                <span class="badge badge-warning mr-2 mb-2">Hiệu chỉnh</span>
              </router-link>
              <router-link
                v-if="currentUser !== null && currentUser.isAdmin"
                :to="'/edit-question/' + currentTest.id"
              >
                <span class="badge badge-danger mr-2 mb-2">Quản lý câu hỏi</span>
              </router-link>
              <router-link :to="'/do-test/' + currentTest.id">
                <span class="badge badge-primary">Làm bài</span>
              </router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import TestDetails from "../components/TestDetails";
import TestService from "../services/test.service";

import ClassicEditor from "@ckeditor/ckeditor5-editor-classic/src/classiceditor";

import EssentialsPlugin from "@ckeditor/ckeditor5-essentials/src/essentials";
import BoldPlugin from "@ckeditor/ckeditor5-basic-styles/src/bold";
import ItalicPlugin from "@ckeditor/ckeditor5-basic-styles/src/italic";
import Underline from "@ckeditor/ckeditor5-basic-styles/src/underline";
import LinkPlugin from "@ckeditor/ckeditor5-link/src/link";
import ParagraphPlugin from "@ckeditor/ckeditor5-paragraph/src/paragraph";

import Image from "@ckeditor/ckeditor5-image/src/image";
import ImageCaption from "@ckeditor/ckeditor5-image/src/imagecaption";
import ImageStyle from "@ckeditor/ckeditor5-image/src/imagestyle";
import ImageToolbar from "@ckeditor/ckeditor5-image/src/imagetoolbar";
import ImageUpload from "@ckeditor/ckeditor5-image/src/imageupload";

import MediaEmbed from "@ckeditor/ckeditor5-media-embed/src/mediaembed";

import Base64UploadAdapter from "@ckeditor/ckeditor5-upload/src/adapters/base64uploadadapter";

export default {
  name: "TestBook",
  components: {
    TestDetails,
  },
  data() {
    return {
      tests: [],
      currentTest: null,
      currentIndex: -1,
      nameToSearch: "",
      showDeleteAll: false,
      currentUser: null,

      editor: ClassicEditor,
      editorData: "<p>Khang.</p>",
      editorConfig: {
        plugins: [
          EssentialsPlugin,
          BoldPlugin,
          ItalicPlugin,
          LinkPlugin,
          Underline,
          ParagraphPlugin,
          Image,
          ImageCaption,
          ImageStyle,
          ImageToolbar,
          ImageUpload,
          MediaEmbed,
          Base64UploadAdapter,
        ],
        toolbar: {
          items: [
            "bold",
            "italic",
            "underline",
            "link",
            "undo",
            "redo",
            "uploadImage",
            "mediaEmbed",
          ],
        },
        image: {
          toolbar: ["imageStyle:full", "imageStyle:side", "|", "imageTextAlternative"],
        },
      },
    };
  },
  methods: {
    setActiveTest(test, index) {
      this.currentTest = test;
      this.currentIndex = test ? index : -1;
    },

    async retrieveTests() {
      const [error, response] = await this.handle(TestService.getAll());
      if (error) {
        console.log(error);
      } else {
        this.tests = response.data;
        console.log(response.data);
      }
    },

    refreshList() {
      this.retrieveTests();
      this.currentTest = null;
      this.currentIndex = -1;
    },

    async removeAllTest() {
      // const [error, response] = await this.handle(TestService.deleteAll());
      // if (error) {
      //   console.log(error);
      // } else {
      //   console.log(response.data);
      //   this.refreshList();
      // }
    },

    goToAddTest() {
      this.$router.push("/add-test");
    },

    async searchName() {
      const [error, response] = await this.handle(
        TestService.findByName(this.nameToSearch)
      );
      if (error) {
        console.log(error);
      } else {
        this.tests = response.data;
        this.setActiveTest(null);
        console.log(response.data);
      }
    },

    getUserName(userId) {
      return `admin${userId}`;
    },
  },
  mounted() {
    this.currentUser = this.$store.getters.loggedInUser;
    this.retrieveTests();
  },
};
</script>

<style>
.list-group-item.active {
  background-color: #4caf50 !important;
  border-color: #4caf50 !important;
}

input:focus,
button:focus {
  outline: none !important;
  box-shadow: none !important;
}
</style>
