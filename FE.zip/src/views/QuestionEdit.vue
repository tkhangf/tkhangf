<template>
  <div class="row">
    <div class="col-md-12">
      <div
        v-for="(question, index) in questions"
        :key="question.id"
        @click="setActiveQuestion(question, index)"
      >
        <div>
          <div>
            {{ question.content }}
          </div>
          <div>
            {{ question.a }}
          </div>
          <div>
            {{ question.b }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import QuestionService from "../services/question.service";

export default {
  name: "QuestionEdit",

  data() {
    return {
      currentTestId: "",
      questions: [],
      currentQuestionId: -1,
      currentQuestion: null,
    };
  },

  methods: {
    async retrieveQuestions(currentId) {
      const [error, response] = await this.handle(QuestionService.getAll(currentId));
      if (error) {
        console.log(error);
      } else {
        this.questions = response.data;
        console.log(response.data);
      }
    },

    setActiveQuestion(question, index) {
      this.currentQuestionId = index;
      this.currentQuestion = question;
    },
  },

  mounted() {
    this.currentTestId = this.$route.params.testId;
    this.retrieveQuestions(this.currentTestId);
  },
};
</script>

<style></style>
