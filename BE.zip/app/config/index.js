const config = {
    app: {
        port: process.env.PORT || 8080
    },
    db: {
        url: "mongodb://localhost:27017/new-anhngusimple"
    },
    jwt: {
        secret: "new-anhngusimple-secret-key"
    }
};

module.exports = config;
